from brain_games.games.even_game import even


def main():
    print('Welcome to the Brain Games!')
    even()


if __name__ == '__main__':
    main()
