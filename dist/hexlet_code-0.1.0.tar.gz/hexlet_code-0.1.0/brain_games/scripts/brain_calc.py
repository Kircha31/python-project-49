from brain_games.games import calc_game as c


def main():
    print('Welcome to the Brain Games!')
    c.calc()


if __name__ == '__main__':
    main()
