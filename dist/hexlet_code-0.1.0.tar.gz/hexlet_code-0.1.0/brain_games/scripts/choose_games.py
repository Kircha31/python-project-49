from brain_games.games.calc_game import calc
from brain_games.games.even_game import even
from brain_games.games.gcd_game import gcd
from brain_games.games.prime_game import prime
from brain_games.games.arfprog_game import progressive
from simple_term_menu import TerminalMenu
from art import tprint


def main():
    print('Welcome to the Brain Games!')
    tprint('In which game you want play')
    
    opt = ["1. brain_calc", "2. brain_even", "3. brain_gcd", "4. brain_progression", "5. brain_prime"]
    ch = TerminalMenu(opt).show()
    print(opt[ch])
    if opt[ch] == "1. brain_calc":
        calc()
    elif opt[ch] == "2. brain_even":
        even()
    elif opt[ch] == "3. brain_gcd":
        gcd()
    elif opt[ch] == "4. brain_progression":
        progressive()
    else:
        prime()

if __name__ == '__main__':
    main()

