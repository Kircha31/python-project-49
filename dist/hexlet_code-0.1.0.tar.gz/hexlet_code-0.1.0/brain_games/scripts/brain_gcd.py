from brain_games.games.gcd_game import gcd


def main():
    print('Welcome to the Brain Games!')
    gcd()


if __name__ == '__main__':
    main()