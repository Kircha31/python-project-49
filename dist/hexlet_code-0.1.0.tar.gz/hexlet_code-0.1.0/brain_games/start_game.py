def correct_answer(user_answer, right_answer):
    if right_answer == user_answer:
        return True
    else:
        return False
