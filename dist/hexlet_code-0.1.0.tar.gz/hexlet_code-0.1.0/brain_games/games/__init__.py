"""Games and its logic."""
__all__ = ['even_game',
           'calc_game',
           'gcd_game',
           'progression_game',
           'prime_game']
