"""Games and its logic."""
__all__ = ['ans_que', 'even_game', 'calc_game', 'gcd_game', 'arfprog_game', 'prime_game']
