### Hexlet tests and linter status:
[![Actions Status](https://github.com/Kircha31/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/Kircha31/python-project-49/actions)
# Install package 
pip install git+https://github.com/Kircha31/python-project-49.git

# Brain-even - Check even number or no 
In this game you have to answer whether the number is even
<a href="https://asciinema.org/a/569288" target="_blank"><img src="https://asciinema.org/a/569288.svg" /></a>

# Brain-calc -  Did you study math well
In this game you have to calculate correctly
<a href="https://asciinema.org/a/569831" target="_blank"><img src="https://asciinema.org/a/569831.svg" /></a>

# Brain-gcd - Find general divisor
In this game you have find common divisor of given numbers
<a href="https://asciinema.org/a/570368" target="_blank"><img src="https://asciinema.org/a/570368.svg" /></a>

# Brain-progression - The detective game
In this game you have find what number is missing in the progression
<a href="https://asciinema.org/a/570444" target="_blank"><img src="https://asciinema.org/a/570444.svg" /></a>

# Brain-prime - In search of a simple
In this game you have find simple number 
brain-prime(number is prime) - 
<a href="https://asciinema.org/a/570714" target="_blank"><img src="https://asciinema.org/a/570714.svg" /></a>