### Hexlet tests and linter status:
[![Actions Status](https://github.com/Kircha31/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/Kircha31/python-project-49/actions)
brain-even(definition even number or no) - https://asciinema.org/a/569288
brain-calc(count number) - https://asciinema.org/a/569831
brain-gcd(greatest common divisor of given numbers) - https://asciinema.org/a/570368
brain-progression(What number is missing in the progression) - https://asciinema.org/a/570444
brain-prime(number is prime) - https://asciinema.org/a/570714