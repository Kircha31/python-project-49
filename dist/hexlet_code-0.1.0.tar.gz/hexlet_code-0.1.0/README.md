### Hexlet tests and linter status:
[![Actions Status](https://github.com/Kircha31/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/Kircha31/python-project-49/actions)
# Install package 
pip install git+https://github.com/Kircha31/python-project-49.git

# Brain-even - Check even number or no 
In this game you have to answer whether the number is even
<script async id="asciicast-569288" src="https://asciinema.org/a/569288.js"></script>

# Brain-calc -  Did you study math well
In this game you have to calculate correctly
<script async id="asciicast-569831" src="https://asciinema.org/a/569831.js"></script>

# Brain-gcd - Find general divisor
In this game you have find common divisor of given numbers
<script async id="asciicast-570368" src="https://asciinema.org/a/570368.js"></script>

# Brain-progression - The detective game
In this game you have find what number is missing in the progression
<script async id="asciicast-570444" src="https://asciinema.org/a/570444.js"></script>

# Brain-prime - In search of a simple
In this game you have find simple number 
brain-prime(number is prime) - 
<script async id="asciicast-570714" src="https://asciinema.org/a/570714.js"></script>