### Hexlet tests and linter status:
[![Actions Status](https://github.com/Kircha31/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/Kircha31/python-project-49/actions)
brain-even(definition even number or no) - https://asciinema.org/a/569288
brain-calc(count number) - https://asciinema.org/a/569831