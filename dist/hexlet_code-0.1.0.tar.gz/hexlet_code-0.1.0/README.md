### Hexlet tests and linter status:
[![Actions Status](https://github.com/Kircha31/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/Kircha31/python-project-49/actions)
# Проверка на четность
brain-even(definition even number or no) - https://asciinema.org/a/569288
# в данной игре выводиться выражение из двух чисел (необходимо дать правильный ответ)
brain-calc(count number) - https://asciinema.org/a/569831
# Наибольший общий делитель 
brain-gcd(greatest common divisor of given numbers) - https://asciinema.org/a/570368
# арефмитическая прогрессия
brain-progression(What number is missing in the progression) - https://asciinema.org/a/570444
# Выявление простого числа 
brain-prime(number is prime) - https://asciinema.org/a/570714
# скрипт choose-game - меня для пользовтаеля для выбора игры 
choose-games - select games
# /games/ans_que
ans_que - All methods are collected for work main scripts