from brain_games.games.calc_game import calc


def main():
    print('Welcome to the Brain Games!')
    calc()


if __name__ == '__main__':
    main()
