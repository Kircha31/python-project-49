from brain_games.start_game import start_game
import brain_games.games.calc_game


def main():
    start_game(brain_games.games.calc_game)


if __name__ == '__main__':
    main()
