from brain_games.games.arfprog_game import progressive


def main():
    print('Welcome to the Brain Games!')
    progressive()


if __name__ == '__main__':
    main()