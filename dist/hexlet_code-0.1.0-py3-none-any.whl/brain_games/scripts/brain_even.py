from brain_games.games import even_game as e
import sys

def main():
    print('Welcome to the Brain Games!')
    
    e.even()


if __name__ == '__main__':
    main()
