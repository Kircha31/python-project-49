from brain_games.games.prime_game import prime


def main():
    print('Welcome to the Brain Games!')
    prime()


if __name__ == '__main__':
    main()